# Gitor
Github python wrapper, Custom made for getting repositories for your python web server.